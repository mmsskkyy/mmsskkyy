#include <iostream>
using namespace std;

class Coord {
public:
    Coord(int rr, int cc) : maze_row(rr), maze_col(cc) {}
    int r() const { return maze_row; }
    int c() const { return maze_col; }
private:
    int maze_row;
    int maze_col;
};

bool pathExists(char maze[][10], int sr, int sc, int er, int ec) {
    if (sr == er && sc == ec)
        return true;

    maze[sr][sc] = 'E'; 

   
    if (sc + 1 < 10 && maze[sr][sc + 1] == '.') {
        if (pathExists(maze, sr, sc + 1, er, ec))
            return true;
    }

   
    if (sr + 1 < 10 && maze[sr + 1][sc] == '.') {
        if (pathExists(maze, sr + 1, sc, er, ec))
            return true;
    }

   
    if (sc - 1 >= 0 && maze[sr][sc - 1] == '.') {
        if (pathExists(maze, sr, sc - 1, er, ec))
            return true;
    }

  
    if (sr - 1 >= 0 && maze[sr - 1][sc] == '.') {
        if (pathExists(maze, sr - 1, sc, er, ec))
            return true;
    }

    return false;
}


int main() {
    char maze[10][10] = {
        { 'X','X','X','X','X','X','X','X','X','X' },
        { 'X','.','.','.','X','.','.','X','.','X' },
        { 'X','.','X','X','X','.','.','.','.','X' },
        { 'X','.','X','.','X','X','X','X','.','X' },
        { 'X','X','X','.','.','.','.','.','.','X' },
        { 'X','.','.','.','X','.','X','X','.','X' },
        { 'X','.','X','.','X','.','.','X','.','X' },
        { 'X','.','X','X','X','X','.','X','.','X' },
        { 'X','.','.','X','.','.','.','X','.','X' },
        { 'X','X','X','X','X','X','X','X','X','X' }
    };
    if (pathExists(maze, 4, 3, 1, 8))
        cout << "Solvable!" << endl;
    else
        cout << "Out of luck!" << endl;
}

